/**
 * @author Ángel Esteban Parra
 */

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class Main {

    public static void main(String[] args) {

        try {
            Process proceso = Runtime.getRuntime().exec("ping -parametroIncorrecto");

            BufferedReader lector = new BufferedReader(
                    new InputStreamReader(proceso.getErrorStream())
            );

            String linea;

            while ((linea = lector.readLine()) != null) {
                System.out.println(linea);
            }

            lector.close();

        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}