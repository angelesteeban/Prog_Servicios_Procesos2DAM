void main() {
    //Creo las impresoras
    Thread impresora01 = new Thread(new Impresora(3, "Impresora A"));
    Thread impresora02 = new Thread(new Impresora(5, "Impresora B"));
    Thread impresora03 = new Thread(new Impresora(4, "Impresora C"));

    //Lanzo los hilos
    impresora01.start();
    impresora02.start();
    impresora03.start();
}
