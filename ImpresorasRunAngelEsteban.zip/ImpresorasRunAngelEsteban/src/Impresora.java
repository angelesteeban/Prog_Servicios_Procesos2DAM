public class Impresora implements Runnable{
    //Declaración vars
    protected int numPaginas;
    protected String nombre;
    private static int contadorHilos = 0;
    private final int idHilo = contadorHilos;

    //Constructor
    public Impresora(int numPaginas, String nombre) {
        this.numPaginas = numPaginas;
        this.nombre = nombre;
        contadorHilos++;
    }

    //Metodo run
    @Override
    public void run() {
        //Contador de páginas que va sumando hasta que se hayan leído todas las páginas
        int contadorPags = 1;
        while (contadorPags < numPaginas+1){
            System.out.println("Hilo: "+idHilo+" impresora: "+nombre+" página actual: "+contadorPags);
            contadorPags++;
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
