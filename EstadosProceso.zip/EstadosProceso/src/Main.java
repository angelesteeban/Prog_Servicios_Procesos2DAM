/**
 * @author Ángel Esteban Parra
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class Main {

    public static void main(String[] args) {

        // Comprobamos el sistema operativo para construir el comando ping.
        String sistemaOperativo = System.getProperty("os.name").toLowerCase();

        List<String> comando;

        if (sistemaOperativo.contains("win")) {
            comando = Arrays.asList("ping", "-n", "4", "127.0.0.1");
        } else {
            comando = Arrays.asList("ping", "-c", "4", "127.0.0.1");
        }

        // Creamos el proceso que ejecutará el comando ping.
        ProcessBuilder processBuilder = new ProcessBuilder(comando);

        // Unificamos la salida estándar y la salida de errores.
        processBuilder.redirectErrorStream(true);

        try {

            // Iniciamos el proceso.
            Process proceso = processBuilder.start();

            // Obtenemos el identificador del proceso.
            long pid = proceso.pid();

            System.out.println("Proceso iniciado.");

            // Comprobamos si el proceso está vivo.
            System.out.println("¿Está vivo?: " + proceso.isAlive());

            // Mostramos el PID.
            System.out.println("PID: " + pid);

            // Obtenemos información adicional mediante ProcessHandle.
            Optional<ProcessHandle> handleOptional = ProcessHandle.of(pid);

            if (handleOptional.isPresent()) {

                ProcessHandle handle = handleOptional.get();

                ProcessHandle.Info info = handle.info();

                // Mostramos el comando ejecutado.
                System.out.println("Comando: "
                        + info.command().orElse("No disponible"));

                // Mostramos los argumentos utilizados.
                System.out.println("Argumentos: "
                        + info.arguments()
                        .map(Arrays::toString)
                        .orElse("No disponibles"));

                // Mostramos el usuario propietario del proceso.
                System.out.println("Usuario: "
                        + info.user().orElse("No disponible"));

            } else {
                System.out.println("No se ha podido obtener información del proceso.");
            }

            System.out.println("Resultados del ping: ");

            // Leemos y mostramos la salida del proceso.
            try (BufferedReader lector = new BufferedReader(
                    new InputStreamReader(
                            proceso.getInputStream(),
                            StandardCharsets.UTF_8))) {

                String linea;

                while ((linea = lector.readLine()) != null) {
                    System.out.println(linea);
                }
            }

            // Esperamos a que el proceso termine.
            int codigoSalida = proceso.waitFor();

            System.out.println("Resultado final: ");

            // Mostramos el código de finalización.
            System.out.println("Código de salida: " + codigoSalida);

            // Comprobamos si la ejecución ha sido correcta.
            System.out.println("Ejecución correcta: " + (codigoSalida == 0));

            // Comprobamos si el proceso sigue vivo después de finalizar.
            System.out.println("¿Sigue vivo?: " + proceso.isAlive());

        } catch (IOException e) {

            // Controlamos errores al iniciar o leer el proceso.
            System.err.println("Error de entrada/salida: " + e.getMessage());

        } catch (InterruptedException e) {

            // Restauramos el estado de interrupción del hilo.
            Thread.currentThread().interrupt();

            System.err.println("El proceso ha sido interrumpido: "
                    + e.getMessage());

        } catch (SecurityException e) {

            // Controlamos posibles problemas de permisos.
            System.err.println("Error de permisos: " + e.getMessage());
        }
    }
}
